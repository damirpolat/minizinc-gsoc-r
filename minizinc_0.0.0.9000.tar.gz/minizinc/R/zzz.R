#' @description
#'
#' @importFrom R6 R6Class
#' @importFrom rlang env
#' @importFrom rjson fromJSON
"_PACKAGE"
