#' R Interface to Minizinc
#'
#' R interface to Minizinc language.
#'
#' @docType package
#' @name minizinc

# package level environment
.globals = env()
.globals$minizinc_path = NULL
