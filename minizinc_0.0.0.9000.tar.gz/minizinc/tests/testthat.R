library(testthat)
library(minizinc)

test_check("minizinc")
