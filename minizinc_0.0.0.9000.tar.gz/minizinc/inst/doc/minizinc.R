## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(minizinc)
par = Variable$new(type = "float", kind = "parameter", value = 0.8)
dec = Variable$new(type = "float", kind = "decision", domain = c(0, 1))

## ------------------------------------------------------------------------
par = Variable$new(type = "float", kind = "parameter", value = 0.8)
var1 = Variable$new(type = "float", kind = "decision", domain = c(0, par$value))
var2 = Variable$new(type = "float", kind = "decision", domain = c(0, par$value))

constraint = Constraint$new(constraint = ">=", variables = c(var1, var2))

## ------------------------------------------------------------------------
s = Solver$new(name = "gecode")

## ------------------------------------------------------------------------
# parameter variable
p1 = Variable$new(type = "int", value = 3, kind = "parameter")

# decision variables
v1 = Variable$new(type = "int", kind = "decision", domain = c(1, p1$value))
v2 = Variable$new(type = "int", kind = "decision", domain = c(1, p1$value))
v3 = Variable$new(type = "int", kind = "decision", domain = c(1, p1$value))
v4 = Variable$new(type = "int", kind = "decision", domain = c(1, p1$value))
v5 = Variable$new(type = "int", kind = "decision", domain = c(1, p1$value))
v6 = Variable$new(type = "int", kind = "decision", domain = c(1, p1$value))
v7 = Variable$new(type = "int", kind = "decision", domain = c(1, p1$value))
vars = c(v1, v2, v3, v4, v5, v6, v7)

# constraints
c1 = Constraint$new(constraint = "!=", variables = c(v1, v2))
c2 = Constraint$new(constraint = "!=", variables = c(v1, v3))
c3 = Constraint$new(constraint = "!=", variables = c(v2, v3))
c4 = Constraint$new(constraint = "!=", variables = c(v2, v4))
c5 = Constraint$new(constraint = "!=", variables = c(v3, v4))
c6 = Constraint$new(constraint = "!=", variables = c(v3, v5))
c7 = Constraint$new(constraint = "!=", variables = c(v3, v6))
c8 = Constraint$new(constraint = "!=", variables = c(v4, v5))
c9 = Constraint$new(constraint = "!=", variables = c(v5, v6))
constr = c(c1, c2, c3, c4, c5, c6, c7, c8, c9)

# solver
s = Solver$new(name  = "gecode")

# putting it all together
m = Model$new(parameter = c(p1), decision = vars, constraints = constr, 
              objective = "satisfy")

## ------------------------------------------------------------------------
set_path("/home/damir/software/MiniZincIDE-2.4.2-bundle-linux/bin/minizinc")

## ------------------------------------------------------------------------
res = solve(m, s)
print(res)

